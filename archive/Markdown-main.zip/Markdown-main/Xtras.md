**Miscellaneous**
1. IIR
    1. LPF_1 (Butterworth)
    2. HPF_1 (Butterworth)
    3. LPF_2 (Butterworth)
    4. HPF_2 (Butterworth)
    5. BPF_2 (Butterworth)
    6. BSF_2 (Butterworth)
    7. APF (All Pass Filter)
    8. QF_1 (Butterworth)
    9. QF_2 (Butterworth)
    10. SRL
    11. FLC
    12. WFLC
    13. BMFLC
2. FIR
    1. MA
    2. Median


**The Cauchy-Schwarz Inequality**
$$\left( \sum_{k=1}^n a_k b_k \right)^2 \leq \left( \sum_{k=1}^n a_k^2 \right) \left( \sum_{k=1}^n b_k^2 \right)$$